#include <iostream>
#include <conio.h>

#include <io_ipc.h>
#include <android.h>

#include <ILedService.h>

using namespace std;
/*
template<typename INTERFACE> class BpInterface : public INTERFACE, public BpRefBase {
	BpInterface(IBinder* p) : BpRefBase(p) {}
	// onAsBinder() ����
};
*/

class BpLedService : public BpInterface<ILedService> {
public:
	BpLedService(IBinder* p) : BpInterface<ILedService>(p) {}

	void LedOn() {
		int msg, reply;
		remote()->transact(1,&msg,&reply);
	}

	void LedOff() {
		int msg, reply;
		remote()->transact(2,&msg,&reply);
	}
};

int main() {
	ProcessState* pro( ProcessState::self() );

	IBinder* svc = getService("kr.co.lg.LedService");
	
	BpLedService* pLed = new BpLedService(svc);

	while(1) {
		getch();
		pLed->LedOn();

		getch();
		pLed->LedOff();
	}
}