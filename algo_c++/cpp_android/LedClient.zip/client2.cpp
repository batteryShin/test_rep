#include <iostream>
#include <conio.h>

#include <io_ipc.h>
#include <android.h>

using namespace std;

/*
// ���δ� ����̹� open/handle�ϴ� Ŭ����
class ProcessState {
public:
	int mDriver;
	int open_driver() {	return binder_open(128*1024); };

private:
	ProcessState() : mDriver( open_driver() ) {}
	ProcessState(const ProcessState&);
	void operator=(ProcessState&);
	static ProcessState* sInstance;

public:
	static ProcessState* self() {
		if( sInstance==0 ) {
			sInstance = new ProcessState;
		}
		return sInstance;
	}
};

ProcessState* ProcessState::sInstance = 0;
*/

int main() {
	ProcessState* pro( ProcessState::self() );

	int msg, reply;

	int ptr = binder_call( pro->mDriver,
							(int*)"kr.co.lg.Ledservice",
							&reply,
							BINDER_SERVICE_MANAGER,
							SVC_MGR_CHECK_SERVICE);

	while(1) {
		getch();
		binder_call(pro->mDriver, &msg, &reply, ptr, 1);

		getch();
		binder_call(pro->mDriver, &msg, &reply, ptr, 2);
	}
}