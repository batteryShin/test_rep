// AddServer.cpp

#include <utils/RefBase.h>
#include <binder/IInterface.h>
#include <binder/Parcel.h>
#include <cstdio>
#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>

using namespace android;

class AddService : public BBinder
{
	public:
		static int instantiate()
		{
			int result = defaultServiceManager()->addService( String16("AddService"), new AddService() );
			return result;
		}

		AddService() {}
		virtual ~AddService() {}

		status_t onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)
		{
			int ret;
			switch(code)
			{
				case 0: 
					{
						pid_t pid = data.readInt32();
						int   num = data.readInt32();
						ret = num + 1000;
						reply->writeInt32(ret);
						return NO_ERROR;
					} 
					break;
				default:
					return BBinder::onTransact(code, data, reply, flags);
			}
		}
};

int main (int argc, char ** argv)
{
	sp<ProcessState> proc(ProcessState::self());
	sp<IServiceManager> sm = defaultServiceManager();
	AddService::instantiate();
	ProcessState::self()->startThreadPool();
	IPCThreadState::self()->joinThreadPool();
}
