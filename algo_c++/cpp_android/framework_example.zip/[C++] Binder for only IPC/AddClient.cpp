
#include <utils/RefBase.h>
#include <binder/IInterface.h>
#include <binder/Parcel.h>
#include <cstdio>
#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>

using namespace android;

class Client
{
	sp<IBinder> binder;

public:
	void add( int input )
	{
		Parcel data, reply;
		data.writeInt32(input);
		binder->transact(0, data, &reply);
		int ret = reply.readInt32();
		printf( "result = %d\n", ret);
	}

	int get_server()
	{
		sp<IServiceManager> sm = defaultServiceManager();
		binder = sm->getService( String16( "AddService"));
		if (binder == 0)
		{
			printf( "server is not active\n" );
			return -1;
		}

		return 0;
	}
};

int main()
{
	int n;
	printf( "input number: " );
	scanf( "%d", &n );

	Client client;
	int ret = client.get_server();
	if( ret < 0 )
	{
		printf( "server connect error\n" );
		return -1;
	}
	
	client.add(n);

	return 0;
}

