// LedServer.cpp

#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IInterface.h>
#include <binder/IServiceManager.h>
#include <binder/IBinder.h>
#include <utils/Log.h>

using namespace android;

enum { LED_ON = 1, LED_OFF };

class ILedService : public IInterface 
{
	public:
		virtual void ledOn() = 0;
		virtual void ledOff() = 0;
		DECLARE_META_INTERFACE(LedService);
};


class BpLedService : public BpInterface<ILedService>
{
	public:
		BpLedService( const sp<IBinder>& binder ) : BpInterface<ILedService>(binder) {}

		virtual void ledOn();
		virtual void ledOff();
};


IMPLEMENT_META_INTERFACE(LedService, "android.my.ledservice");

class LedService : public BnInterface<ILedService>
{
	public:
		virtual void ledOn() { printf( "[LedService] LED ON\n"); }
		virtual void ledOff() { printf( "[LedService] LED OFF\n" ); }

		status_t onTransact( uint32_t code, const Parcel& data,
			   	Parcel* reply, uint32_t flags)
		{
			switch(code)
			{
				case LED_ON: ledOn(); return NO_ERROR;
				case LED_OFF: ledOff(); return NO_ERROR;	 
				default: return BBinder::onTransact( code, data, reply, flags);
			}
		}
};

int main()
{
	sp<ProcessState> proc(ProcessState::self());	// binder_open
	sp<IServiceManager> sm = defaultServiceManager();
	sm->addService( String16("LedService"), new LedService, false );
	IPCThreadState::self()->joinThreadPool();	// binder_loop
}
