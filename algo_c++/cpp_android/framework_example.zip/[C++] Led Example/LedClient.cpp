#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IInterface.h>
#include <binder/IServiceManager.h>
#include <binder/IBinder.h>
#include <utils/Log.h>

using namespace android;

enum { LED_ON = 1, LED_OFF };

class ILedService : public IInterface
{
	public:
		// 1. interface 
		virtual void ledOn() = 0;
		virtual void ledOff() = 0;

		// 2. asInterface
		DECLARE_META_INTERFACE(LedService);
};

//--------------------------------------- ILedService.h

class BpLedService : public BpInterface<ILedService>
{
	public:
		BpLedService( const sp<IBinder>& binder ) : BpInterface<ILedService>(binder) {}

		virtual void ledOn()
		{
			Parcel send, reply;
			remote()->transact( LED_ON, send, &reply );
		}
		virtual void ledOff()
		{
			Parcel send, reply;
			remote()->transact( LED_OFF, send, &reply );
		}
};

IMPLEMENT_META_INTERFACE(LedService, "android.my.ledservice" );

int main()
{
	sp<IServiceManager> sm = defaultServiceManager();
	sp<IBinder> binder = sm->getService( String16("LedService") );
	sp<ILedService> ledService = interface_cast<ILedService>(binder);

	while(1)
	{
		getchar(); ledService->ledOn();
		getchar(); ledService->ledOff();
	}

	return 0;
}

