/* Copyright 2008 The Android Open Source Project
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "binder.h"

void *svcmgr_lookup(struct binder_state *bs, void *target, const char *name)
{
    void *ptr;
    unsigned iodata[512/4];
    struct binder_io msg, reply;

    bio_init(&msg, iodata, sizeof(iodata), 4);
    bio_put_uint32(&msg, 0);  // strict mode header
    bio_put_string16_x(&msg, SVC_MGR_NAME);
    bio_put_string16_x(&msg, name);

	// 2. ���� �Ŵ���(0)���Լ�  Ư�� ������ ��ȣ�� �˾� �´�.
    if (binder_call(bs, &msg, &reply, target, SVC_MGR_CHECK_SERVICE))
        return 0;

    ptr = bio_get_ref(&reply);

    if (ptr)
        binder_acquire(bs, ptr);

    binder_done(bs, &msg, &reply);

    return ptr;
}

unsigned token;

int main(int argc, char **argv)
{
    int fd;
    struct binder_state *bs;
	void *svcmgr = BINDER_SERVICE_MANAGER;	// 0
    unsigned iodata[512/4];
    struct binder_io msg, reply;
	void *ptr;

	// 1. ���δ� ����̹� ���� 
	bs = binder_open(128*1024);

	ptr = svcmgr_lookup(bs, svcmgr, "LedService");
	bio_init( &msg, iodata, sizeof(iodata), 4 );

	while(1)
	{
		getchar(); binder_call( bs, &msg, &reply, ptr, 1 );
		getchar(); binder_call( bs, &msg, &reply, ptr, 2 );
	}

	return 0;
}
