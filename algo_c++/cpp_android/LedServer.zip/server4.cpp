#include <iostream>
#include <conio.h>
#include <IO_IPC.h>
#include <android.h>

using namespace std;

/*
class ILedService {
public:
	virtual void LedOn() = 0;
	virtual void LedOff() = 0;
	virtual ~ILedService() {}
};
*/
#include <ILedService.h>

class BnLedService : public BnInterface<ILedService> {
public:
	virtual int onTransact(int code,int* msg, int* reply) {
		switch(code) {
		case 1:	LedOn();	break;
		case 2:	LedOff();	break;
		}
		return 0;
	}
};

class LedService : public BnLedService {
public:
	virtual void LedOn()	{ cout << "Led On" << endl; }
	virtual void LedOff()	{ cout << "Led Off" << endl; }
};

int main() {
	ProcessState* pro( ProcessState::self() );

	addService( new LedService, "kr.co.lg.LedService");

	IPCThreadState::self()->joinThreadPool();
}